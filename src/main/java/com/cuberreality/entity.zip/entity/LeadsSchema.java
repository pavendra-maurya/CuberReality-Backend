package com.cuberreality.entity;

public class LeadsSchema {
}
