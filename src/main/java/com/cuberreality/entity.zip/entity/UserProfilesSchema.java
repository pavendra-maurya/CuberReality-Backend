package com.cuberreality.entity;

public class UserProfilesSchema  {

}
